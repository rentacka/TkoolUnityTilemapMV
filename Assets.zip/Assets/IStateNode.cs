﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets
{
    public class IStateNode
    {
        // ExecuteするときにLog(ClassName)としたら、どの動作かってのも追跡できる

        //ステート
        public IStateNode NextState;
        public static IStateNode CurState;

        //デリゲート
        public delegate void executeState();
        public executeState execDelegate;

        //実行処理
        public virtual void Execute()
        {
            if (execDelegate != null)
            {
                execDelegate();
            }

            CurState = NextState;
        }

        public void Log(string logName = null)
        {

        }

        public static void NextMethod(IStateNode pin)
        {
            CurState = pin;
            pin.NextState.Execute();
        }
    }
}
