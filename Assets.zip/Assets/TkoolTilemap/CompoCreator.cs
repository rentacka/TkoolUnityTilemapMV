﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections;

namespace Assets
{
    class CompoCreator
    {
        TkoolJsonData.MapInfoItem mapinfo;

        public CompoCreator(string mapDir)
        {
            var mapInfoPath = System.IO.Path.Combine(mapDir, "MapInfos.json");
            mapinfo = (TkoolJsonData.MapInfoItem)JsonSon.Read(mapInfoPath);
        }

        public static Tilemap AddGridTilemapObj()
        {
            GameObject parentGrid = new GameObject();
            Object.Instantiate(parentGrid);
            parentGrid.AddComponent<Grid>();

            GameObject tilemapObj = new GameObject();
            Object.Instantiate(tilemapObj);
            // tilemapの親にGridを設定
            tilemapObj.transform.parent = parentGrid.transform;
            tilemapObj.AddComponent<Tilemap>();
            tilemapObj.AddComponent<TilemapRenderer>();

            var tilemapComponent = tilemapObj.GetComponent<Tilemap>();
            return tilemapComponent;
        }
    }
}
