﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets
{
    public enum Setnumbers
    {
        B=0,
        C= 256,
        D = 512,
        A5 = 1536,
        A1 = 2048,
        A2 = 2816,
        A3 = 4352,
        A4 = 5888
    }
}
