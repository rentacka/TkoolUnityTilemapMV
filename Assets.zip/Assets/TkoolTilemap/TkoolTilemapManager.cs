﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Assets
{
    class TkoolTilemapManager : baseFramework
    {
        bool isInit = false;
        static Dictionary<string, TkoolJsonData.Map> maps;
        static List<TkoolJsonData.MapInfoItem> mapinfoes;
        static List<TkoolJsonData.Tilesets> tilesets;

        static string tilesetsPath = null;

        public static Vector2 TileSize = new Vector2(48, 48);

        #region TkoolTilemapManager
        /// <summary>
        /// マップをデータフォルダから読み込み
        /// </summary>
        public TkoolTilemapManager()
        {
            string foldaPath = "img\tilesets";

            if(isInit == false)
                Setup(foldaPath, null, true);
            isInit = true;
        }

        /// <summary>
        /// マップをデータフォルダから読み込み
        /// </summary>
        /// <param name="foldaPath"></param>
        public TkoolTilemapManager(string foldaPath)
        {
            if (isInit == false)
                Setup(foldaPath, null, true);
            isInit = true;
        }

        /// <summary>
        /// マップをWindowsパスから読み込み
        /// </summary>
        /// <param name="foldaPath"></param>
        /// <param name="projPath"></param>
        public TkoolTilemapManager(string foldaPath, string projPath)
        {
            if (isInit == false)
                Setup(foldaPath, projPath, false);
            isInit = true;
        }

        void Setup(string foldaPath, string projPath = null, bool isDataPath = false)
        {
            if (projPath != null)
            {
                if (isDataPath)
                {
                    // Application.dataPathで/Assets/filePathになる
                    tilesetsPath = Application.dataPath + foldaPath;
                }
                else
                    tilesetsPath = Path.Combine(projPath, foldaPath);


                // Map001～Map999.jsonをを読み込み
                Dictionary<string, string> mapTiles = new Dictionary<string, string>();
                var allPathes = System.IO.Directory.GetFiles(tilesetsPath);
                foreach (var file in allPathes)
                {
                    var assetName = System.IO.Path.GetFileNameWithoutExtension(file);

                    if (assetName.Contains("Map") && IsNumeric(assetName))
                    {
                        mapTiles.Add(assetName, file);
                    }
                }

                foreach (var mapTilePath in mapTiles)
                {
                    var Mapmap = (TkoolJsonData.Map)JsonSon.Read(mapTilePath.Key + ".json", mapTilePath.Value);
                    maps.Add(mapTilePath.Key, Mapmap);
                }

                // MapInfos.jsonを読み込み
                mapinfoes = (List<TkoolJsonData.MapInfoItem>)JsonSon.Read("MapInfos.json", tilesetsPath);

                // tilesets.jsonを読み込み
                tilesets = (List<TkoolJsonData.Tilesets>)JsonSon.Read("Tilesets.json", tilesetsPath);
            }
        }

        public bool IsNumeric(string stTarget)
        {
            double dNullable;

            return double.TryParse(
                stTarget,
                System.Globalization.NumberStyles.Any,
                null,
                out dNullable
            );
        }
        #endregion TkoolTilemapManager

        #region CreateTileID
        /// <summary>
        /// タイルのID作成
        /// </summary>
        /// <param name="setnumber">セットの開始番号:B,C,D,E,A5</param>
        /// <param name="tilenumber">タイル番号</param>
        /// <returns></returns>
        public static int CreateTileID(Setnumbers setnumber, int tilenumber)
        {
            return CreateTileID((int)setnumber, tilenumber);
        }

        /// <summary>
        /// タイルのID作成
        /// </summary>
        /// <param name="setnumber">セットの開始番号:B,C,D,E,A5</param>
        /// <param name="tilenumber">タイル番号</param>
        /// <returns></returns>
        public static int CreateTileID(int setnumber, int tilenumber)
        {
            return setnumber + tilenumber;
        }
        #endregion CreateTileID

        #region CreateAutoTileID
        /// <summary>
        /// オートタイルのID作成
        /// </summary>
        /// <param name="setnumber">セットの開始番号:A1～A4</param>
        /// <param name="numberID">種別ID:ブロック番号</param>
        /// <param name="shapeID">形状ID：ブロック内のタイル番号</param>
        /// <returns></returns>
        public static int CreateAutoTileID(Setnumbers setnumber, int numberID, int shapeID)
        {
            if (setnumber == Setnumbers.A1)
                numberID = numberID + 0;
            if (setnumber == Setnumbers.A2)
                numberID = numberID + 16;
            if (setnumber == Setnumbers.A3)
                numberID = numberID + 48;
            if (setnumber == Setnumbers.A4)
                numberID = numberID + 80;

            var result = (int)setnumber + numberID * 48 + shapeID;

            return result;
        }
        #endregion CreateAutoTileID

        #region CreateDataIndex
        public static int CreateDataIndex(TkoolJsonData.MapInfoItem mapInfo, Vector2 point, TilemapFloors _z)
        {
            var index = point.x + (point.y * mapInfo.ScrollX) + ((int)_z * mapInfo.ScrollX * mapInfo.ScrollY);

            return (int)index;
        }
        #endregion CreateDataIndex

        #region GetnumberID
        /// <summary>
        /// 種別ID取得
        /// </summary>
        /// <param name="tileID"></param>
        /// <returns></returns>
        public static int GetnumberID(int tileID)
        {
            int number = 0;
            for (int i = 0; i <= 8192;)
            {
                if (tileID < i)
                {
                    break;
                }

                number++;

                var setnum = iGetSetnumbers(i);
                var setnum2 = iGetSetnumbers(i + 48);
                if (setnum != setnum2)
                    number = 0;

                i += 48;
            }

            return number;
        }
        #endregion GetnumberID

        #region GetShapID
        /// <summary>
        /// 形状ID取得
        /// </summary>
        /// <param name="tileID"></param>
        public static int GetShapID(int tileID)
        {
            // セットの開始番号を取得
            var setnumber = iGetSetnumbers(tileID);

            // 種別ID取得
            var numberID = GetnumberID(tileID);

            var shapeID = tileID - setnumber - numberID * 48;

            return shapeID;
        }
        #endregion GetShapID

        #region GetAutotileTypes
        AutotileTypes GetAutotileTypes(int tileID)
        {
            var intVal = iGetAutotileTypes(tileID);
            var enmVal = (AutotileTypes)Enum.ToObject(typeof(AutotileTypes), intVal);

            return enmVal;
        }

        int iGetAutotileTypes(int tileID)
        {
            var setnum = iGetSetnumbers(tileID);

            if (setnum >= 2048 && setnum <= 8144)
            {
                if (setnum >= 2048 && setnum <= 4532)
                {
                    // A1
                    if (tileID >= 2288 && 2336 > tileID)
                    {
                        return 3;
                    }

                    if (tileID >= 2384 && 2432 > tileID)
                    {
                        return 3;
                    }

                    if (tileID >= 2480 && 2528 > tileID)
                    {
                        return 3;
                    }

                    if (tileID >= 2576 && 2624 > tileID)
                    {
                        return 3;
                    }

                    if (tileID >= 2672 && 2720 > tileID)
                    {
                        return 3;
                    }

                    if (tileID >= 2768 && 2816 > tileID)
                    {
                        return 3;
                    }

                    // A3
                    if (tileID >= 4352 && 5888 > tileID)
                    {
                        return 2;
                    }

                    return 1;
                }
                else
                {
                    // A4
                    if (tileID >= 5888 && 6272 > tileID || tileID >= 6656 && 7040 > tileID || tileID >= 7424 && 7808 > tileID)
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                }
            }
            else
            {
                return 0;
            }
        }
        #endregion GetAutotileTypes

        #region GetSetnumbers
        public static Setnumbers GetSetnumbers(int tileId)
        {
            var intVal = iGetSetnumbers(tileId);
            var enmVal = (Setnumbers)Enum.ToObject(typeof(Setnumbers), intVal);

            return enmVal;
        }

        public static int iGetSetnumbers(int tileId)
        {
            if (tileId >= 0 && tileId < 256)
                return 0;
            if (tileId >= 256 && tileId < 512)
                return 256;
            if (tileId >= 512 && tileId < 1536)
                return 512;

            if (tileId >= 1536 && tileId < 2048)
                return 1536;
            if (tileId >= 2048 && tileId < 2816)
                return 2048;
            if (tileId >= 2816 && tileId < 4352)
                return 2816;
            if (tileId >= 4352 && tileId < 5888)
                return 4352;

            //if (tileId >= 5888 && tileId <= 8192)
            return 5888;
        }
        #endregion GetSetnumbers

        #region GetNumberXY
        Vector2 GetNumberXY(Vector2 imgSize, int number)
        {
            var maxX = (int)imgSize.x / (int)TileSize.x;
            var maxY = (int)imgSize.y / (int)TileSize.y;

            return GetNumberXY(maxX, maxY, number);
        }

        Vector2 GetNumberXY(int maxX, int maxY, int number)
        {
            int x = 1, y = 1;
            int i = 1;
            for (; i <= number;)
            {
                for (int j = 1; j <= maxX; j++)
                {
                    i++;

                    x = j;
                }

                y++;
            }

            return new Vector2(x, y);
        }
        #endregion GetNumberXY

        #region GetShapA1ID
        /// <summary>
        /// A1の左から順番に数えたID取得
        /// </summary>
        /// <param name="tileID"></param>
        /// <returns></returns>
        static int GetShapA1ID(int tileID)
        {
            // A1

            // Floor Type
            if (tileID >= 2048 && 2096 > tileID)
            {
                return 0;
            }
            // Floor Type
            if (tileID >= 2096 && 2144 > tileID)
            {

                return 4;
            }
            // Floor Type
            if (tileID >= 2144 && 2192 > tileID)
            {

                return 1;
            }
            // Floor Type
            if (tileID >= 2192 && 2240 > tileID)
            {
                return 5;
            }
            // Floor Type
            if (tileID >= 2240 && 2288 > tileID)
            {
                return 2;
            }
            // Waterfall Type
            if (tileID >= 2288 && 2336 > tileID)
            {
                return 3;
            }
            // Floor Type
            if (tileID >= 2336 && 2384 > tileID)
            {
                return 6;
            }
            // Waterfall Type
            if (tileID >= 2384 && 2432 > tileID)
            {
                return 7;
            }
            // Floor Type
            if (tileID >= 2432 && 2480 > tileID)
            {
                return 8;
            }
            // Waterfall Type
            if (tileID >= 2480 && 2528 > tileID)
            {
                return 9;
            }
            // Floor Type
            if (tileID >= 2528 && 2576 > tileID)
            {
                return 12;
            }
            // Waterfall Type
            if (tileID >= 2576 && 2624 > tileID)
            {
                return 13;
            }
            // Floor Type
            if (tileID >= 2624 && 2672 > tileID)
            {
                return 10;
            }
            // Waterfall Type
            if (tileID >= 2672 && 2720 > tileID)
            {
                return 11;
            }
            // Floor Type
            if (tileID >= 2720 && 2768 > tileID)
            {
                return 14;
            }
            // Waterfall Type
            //if (tileID >= 2768 && 2816 > tileID)
            {
                return 15;
            }
        }
        #endregion GetShapA1ID

        #region GetTileData
        #region GetA1Rect
        Rect GetA1Rect(int tileID, int number)
        {
            var blockNumber = GetShapA1ID(tileID);

            var numberXY = GetNumberXY(4, 4, blockNumber);

            var tileNum = GetA1Pt(blockNumber, numberXY);

            var blockPt = new Vector2(tileNum.x * TileSize.x, tileNum.y * TileSize.y);

            //var rr = new TileData();
            //rr.tileID = tileID;

            Rect rec = new Rect();

            // PixIDのFloorTypeが３個なら
            if (number == 0 || number == 2 || number == 4 || number == 6 || number == 8 || number == 10 || number == 12 || number == 14)
            {
                rec = new Rect(blockPt, new Vector2(2 * TileSize.x * 3, 3 * TileSize.y));

                // Floor×３の座標で画像タイルを取得
                return rec;
            }
            else
            {
                rec = new Rect(blockPt, new Vector2(2 * TileSize.x, 3 * TileSize.y));

                return rec;
            }
        }

        Vector2 GetA1Pt(int number, Vector2 xy)
        {
            bool isFloor = false;
            int seq = 0;
            int tileX = 0;
            for (int i = 0; i < xy.y;)
            {
                for (int j = 0; j < xy.x; j++)
                {
                    // floor×３
                    if (seq % 2 == 0)
                        isFloor = true;
                    else
                        isFloor = false;

                    seq++;


                    if (isFloor)
                        tileX += 3;
                    else
                        tileX += 2;
                }

                break;
            }

            return new Vector2(tileX,xy.y * 3);
        }
        #endregion GetA1Rect

        #region GetA23_Rect
        Rect GetA23_Rect(int tileID,int blockNumber,int setNumX,int setNumY ,int blockNumX,int blockNumY)
        {
            var numberXY = GetNumberXY(setNumX, setNumY, blockNumber);

            int tileNumX = 0;
            int tileNumY = 0;
            if (numberXY.x > 1)
                tileNumX = (int)(numberXY.x-1) * blockNumX;
            if (numberXY.y > 1)
                tileNumY = (int)(numberXY.y - 1) * blockNumY;

            var blockPt = new Vector2(tileNumX * TileSize.x, tileNumY * TileSize.y);

            return new Rect(blockPt, new Vector2(blockNumX * TileSize.x, blockNumY * TileSize.y));
        }
        #endregion GetA23_Rect

        #region GetA4_Rect
        Rect GetA4_Rect(int tileID,int blockNumber)
        {
            var numberXY = GetNumberXY(8, 6, blockNumber);

            int blockNumX = 0;
            int blockNumY = 0;

            var tileNum = GetA4Pt(blockNumber, numberXY);

            var blockPt = new Vector2(tileNum.x * TileSize.x, tileNum.y * TileSize.y);

            return new Rect(blockPt, new Vector2(blockNumX * TileSize.x, blockNumY * TileSize.y));
        }

        Vector2 GetA4Pt(int number, Vector2 xy)
        {
            bool isFloor = false;
            int seq = 0;
            int tileY = 0;
            for (int i = 0; i < xy.y; i++)
            {
                for (int j = 0; j < xy.x;)
                {
                    // floor
                    if (seq >= 0 && seq <= 7 || seq >= 16 && seq <= 23 || seq >= 32 && seq <= 39)
                        isFloor = true;
                    else
                        isFloor = false;

                    seq += (int)xy.x - 1;

                    break;
                }

                if (isFloor)
                    tileY += 3;
                else
                    tileY += 2;
            }

            return new Vector2(xy.x * 2, tileY);
        }
        #endregion GetA4_PixelRect

        bool ExistAnimationTile(int numberPixID)
        {
            if (numberPixID == 0 || numberPixID == 2 || numberPixID == 4 || numberPixID == 6 || numberPixID == 8 || numberPixID == 10 || numberPixID == 12 || numberPixID == 14)
            {
                return true;
            }

            return false;
        }

        public TileData GetTileData(int tileID)
        {
            // セットの開始番号を取得
            var setnumber = iGetSetnumbers(tileID);

            var tileData = new TileData() { setnumber = setnumber, shapID = GetShapID(tileID) };

            tileData.AutotileType = iGetAutotileTypes(tileID);

            // A1,A2,A3,A4,A5
            if (setnumber == 2048 || setnumber == 2816 || setnumber == 4352 || setnumber == 5888 || setnumber == 1536)
            {
                // 種別ID取得
                var numberPixID = GetnumberID(tileID);

                bool isA4 = true;
                // A1
                if (setnumber == 2048)
                {
                    tileData.rect = GetA1Rect(tileID, numberPixID);

                    // アニメーションタイルはA1のみ
                    tileData.IsAnimationTile = ExistAnimationTile(numberPixID);

                    isA4 = false;
                }
                // A2
                if (setnumber == 2816)
                {
                    tileData.rect = GetA23_Rect(tileID, numberPixID, 8, 4, 2, 3);

                    isA4 = false;
                }
                // A3
                if (setnumber == 4352)
                {
                    tileData.rect = GetA23_Rect(tileID, numberPixID, 8, 4, 2, 2);

                    isA4 = false;
                }

                // A4,A5～
                if(isA4)
                    tileData.rect = GetA4_Rect(tileID, numberPixID);

                return tileData;
            }

            // B,C,D
            //if (setnumber == 0 || setnumber == 256 || setnumber == 512)
            {
                tileData.rect = new Rect(new Vector2(TileSize.x * 16, TileSize.y * 16), new Vector2(TileSize.x, TileSize.y));

                return tileData;
            }
        }
        #endregion GetTileData

        #region GetSetnumbersBasicSize
        Vector2 GetSetnumbersBasicSize(int setnumber)
        {
            // A1
            if (setnumber == 2048)
                return new Vector2(768,576);
            // A2
            if (setnumber == 2816)
                return new Vector2(768, 576);
            // A3
            if (setnumber == 4352)
                return new Vector2(768, 576);
            // A4
            if (setnumber == 5888)
                return new Vector2(768, 720);
            // A5
            if (setnumber == 1536)
                return new Vector2(384, 768);

            // B
            if (setnumber == 0)
                return new Vector2(768, 768);
            // C
            //if (setnumber == 256)
                return new Vector2(768, 768);
            // D
            //if (setnumber == 512)
            //    return new Vector2(768, 576);


        }
        #endregion GetSetnumbersBasicSize

        #region ReadTexture2D
        public Texture2D ReadTexture2D(string fileName)
        {
            Texture2D tex2d = ReadPng(fileName);
            tex2d.Apply(true, true);

            return tex2d;
        }
        #endregion ReadTexture2D

        #region TilesetsData
        public class TilesetsData
        {
            public class TilesetImage
            {
                public Texture2D tex2D;
                public string Name;
            }

            public TilesetImage[] tilesets2d;
            public TkoolJsonData.Tilesets tilesets;

            public string GetTilesetName(int setnumber)
            {
                var setnumberStr = ((Setnumbers)setnumber).ToString();

                foreach (var tileset2d in tilesets2d)
                {
                    if(tileset2d.Name.EndsWith("_" + setnumberStr))
                        return tileset2d.Name;
                }

                return null;
            }

            public Texture2D GetTexture2D(string tilesetName)
            {
                foreach (var tileset2d in tilesets2d)
                {
                    if (tilesetName == tileset2d.Name)
                        return tileset2d.tex2D;
                }

                return null;
            }

            public Sprite GetSprite(Rect rect,string tilesetName)
            {
                var tileset2d = GetTexture2D(tilesetName);

                 Sprite sp = Sprite.Create(tileset2d, rect, new Vector2(0.0f, 0.0f), 1.0f);

                return sp;
            }
        }
        #endregion TilesetsData

        #region GetTilesetsData
        public TilesetsData[] GetTilesetsData(int tilesetID)
        {
            List<TilesetsData> TilesetsDatas = new List<TilesetsData>();

            foreach (var tileset in tilesets)
            {
                if (tileset.Id == tilesetID)
                {
                    TilesetsData targetData = new TilesetsData();

                    List<TilesetsData.TilesetImage> imgs = new List<TilesetsData.TilesetImage>();
                    foreach (var fileNameWihoutExt in tileset.TilesetNames)
                    {
                        var fileName = Path.Combine(tilesetsPath, fileNameWihoutExt + ".png");
                        var tex2D = ReadTexture2D(fileName);

                        imgs.Add(new TilesetsData.TilesetImage() { tex2D= tex2D,Name = fileNameWihoutExt});
                    }
                    targetData.tilesets2d = imgs.ToArray();
                    targetData.tilesets = tileset;

                    TilesetsDatas.Add(targetData);

                    break;
                }
            }

            return TilesetsDatas.ToArray();
        }
        #endregion GetTilesetsData

        public class ShapData
        {
            public Rect x1;
            public Rect x2;
            public Rect x3;
            public Rect x4;

            public bool IsAutoShape = true;
        }

        #region TileData
        public class TileData
        {
            public int setnumber;
            public int shapID;
            public Rect rect;

            public int AutotileType;
            public bool IsAnimationTile = false;

            static Vector2 halfTile;
            static bool isInit = false;
            static Rect f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f16, f17, f20, f21, f22, f23, f24;
            static Rect w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16;
            static Rect t1, t2, t3, t4, t5, t6, t7, t8;

            #region TileData
            public TileData()
            {
                if (isInit == false)
                {
                    halfTile = new Vector2(TileSize.x / 2, TileSize.y / 2);

                    f1 = new Rect(new Vector2(0, 0), halfTile);
                    f2 = new Rect(new Vector2(halfTile.x, 0), halfTile);
                    f3 = new Rect(new Vector2(halfTile.x * 2, 0), halfTile);
                    f4 = new Rect(new Vector2(halfTile.x * 3, 0), halfTile);

                    f5 = new Rect(new Vector2(0, halfTile.y), halfTile);
                    f6 = new Rect(new Vector2(halfTile.x, halfTile.y), halfTile);
                    f7 = new Rect(new Vector2(halfTile.x * 2, halfTile.y), halfTile);
                    f8 = new Rect(new Vector2(halfTile.x * 3, halfTile.y), halfTile);

                    f9 = new Rect(new Vector2(0, halfTile.y * 2), halfTile);
                    f10 = new Rect(new Vector2(halfTile.x, halfTile.y * 2), halfTile);
                    f11 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 2), halfTile);
                    f12 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 2), halfTile);

                    f13 = new Rect(new Vector2(0, halfTile.y * 3), halfTile);
                    f16 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 3), halfTile);

                    f17 = new Rect(new Vector2(0, halfTile.y * 4), halfTile);
                    f20 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 4), halfTile);

                    f21 = new Rect(new Vector2(0, halfTile.y * 5), halfTile);
                    f22 = new Rect(new Vector2(halfTile.x, halfTile.y * 5), halfTile);
                    f23 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 5), halfTile);
                    f24 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 5), halfTile);

                    w1 = new Rect(new Vector2(0, 0), halfTile);
                    w2 = new Rect(new Vector2(halfTile.x, 0), halfTile);
                    w3 = new Rect(new Vector2(halfTile.x * 2, 0), halfTile);
                    w4 = new Rect(new Vector2(halfTile.x * 3, 0), halfTile);

                    w5 = new Rect(new Vector2(0, halfTile.y), halfTile);
                    w6 = new Rect(new Vector2(halfTile.x, halfTile.y), halfTile);
                    w7 = new Rect(new Vector2(halfTile.x * 2, halfTile.y), halfTile);
                    w8 = new Rect(new Vector2(halfTile.x * 3, halfTile.y), halfTile);

                    w9 = new Rect(new Vector2(0, halfTile.y * 2), halfTile);
                    w10 = new Rect(new Vector2(halfTile.x, halfTile.y * 2), halfTile);
                    w11 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 2), halfTile);
                    w12 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 2), halfTile);

                    w13 = new Rect(new Vector2(0, halfTile.y * 3), halfTile);
                    w14 = new Rect(new Vector2(halfTile.x, halfTile.y * 3), halfTile);
                    w15 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 3), halfTile);
                    w16 = new Rect(new Vector2(halfTile.x * 3, halfTile.y * 3), halfTile);

                    t1 = new Rect(new Vector2(0, 0), halfTile);
                    t2 = new Rect(new Vector2(halfTile.x, 0), halfTile);
                    t3 = new Rect(new Vector2(halfTile.x * 2, 0), halfTile);
                    t4 = new Rect(new Vector2(halfTile.x * 3, 0), halfTile);
                    t5 = new Rect(new Vector2(0, halfTile.y), halfTile);
                    t6 = new Rect(new Vector2(halfTile.x, halfTile.y), halfTile);
                    t7 = new Rect(new Vector2(halfTile.x * 2, halfTile.y), halfTile);
                    t8 = new Rect(new Vector2(halfTile.x * 3, halfTile.y), halfTile);
                }

                isInit = true;
            }
            #endregion TileData

            ShapData GetShapData()
            {
                #region 床 shapID 0～47
                if (AutotileType == 1)
                {
                    ShapData shapRect = new ShapData
                    {
                        x1 = new Rect(new Vector2(halfTile.x, halfTile.y * 3), halfTile),//14
                        x2 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 3), halfTile),//15
                        x3 = new Rect(new Vector2(halfTile.x, halfTile.y * 4), halfTile),//18
                        x4 = new Rect(new Vector2(halfTile.x * 2, halfTile.y * 4), halfTile)//19
                    };

                    #region 4方向隣接パターン (16通り)
                    if (shapID == 0)
                    {
                        // 14,15,18,19
                        return shapRect;
                    }

                    if (shapID == 1)
                    {
                        // 3,15,18,19
                        shapRect.x1 = f3;
                    }

                    if (shapID == 2)
                    {
                        // 14,4,18,19
                        shapRect.x2 = f4;
                    }

                    if (shapID == 3)
                    {
                        // 3,4,18,19
                        shapRect.x1 = f3;
                        shapRect.x2 = f4;
                    }

                    if (shapID >= 4 && shapID <= 7)
                    {
                        //if (shapID == 4)
                        shapRect.x4 =f8;

                        if (shapID == 5)
                            shapRect.x1 = f3;

                        if (shapID == 6)
                            shapRect.x2 = f4;

                        if (shapID == 7)
                        {
                            shapRect.x1 = f3;
                            shapRect.x2 = f4;
                        }
                    }

                    if (shapID >= 8 && shapID <= 11)
                    {
                        //if (shapID == 8)
                        shapRect.x3 = f7;

                        if (shapID == 9)
                            shapRect.x1 = f3;

                        if (shapID == 10)
                            shapRect.x2 = f4;

                        if (shapID == 11)
                        {
                            shapRect.x1 = f3;
                            shapRect.x2 = f4;
                        }
                    }

                    if (shapID >= 12 && shapID <= 15)
                    {
                        //if (shapID == 12)
                        shapRect.x3 = f7;
                        shapRect.x4 = f8;

                        if (shapID == 13)
                            shapRect.x1 = f3;

                        if (shapID == 14)
                            shapRect.x2 = f4;

                        if (shapID == 15)
                        {
                            shapRect.x1 = f3;
                            shapRect.x2 = f4;
                        }
                    }
                    #endregion 4方向隣接パターン (16通り)

                    #region 3方向隣接パターン (16通り)
                    if (shapID >= 16 && shapID <= 19)
                    {
                        //if (shapID == 16)
                        // 13,17
                        shapRect.x1 = f17;
                        shapRect.x3 = f13;

                        if (shapID == 17)
                            shapRect.x2 = f4;

                        if (shapID == 18)
                            shapRect.x4 = f8;

                        if (shapID == 19)
                        {
                            shapRect.x2 = f4;
                            shapRect.x4 = f8;
                        }
                    }

                    if (shapID >= 20 && shapID <= 23)
                    {
                        //if (shapID == 20)
                        // 10,11
                        shapRect.x1 = f11;
                        shapRect.x2 = f10;

                        if (shapID == 21)
                            shapRect.x4 = f8;

                        if (shapID == 22)
                            shapRect.x3 = f7;

                        if (shapID == 23)
                        {
                            shapRect.x3 = f7;
                            shapRect.x4 = f8;
                        }
                    }

                    if (shapID >= 24 && shapID <= 27)
                    {
                        //if (shapID == 24)
                        // 16,20
                        shapRect.x2 = f20;
                        shapRect.x4 = f16;

                        if (shapID == 25)
                            shapRect.x3 = f7;

                        if (shapID == 26)
                            shapRect.x1 = f3;

                        if (shapID == 27)
                        {
                            shapRect.x1 = f3;
                            shapRect.x3 = f7;
                        }
                    }

                    if (shapID >= 28 && shapID <= 31)
                    {
                        //if (shapID == 28)
                        // 22,23
                        shapRect.x3 = f23;
                        shapRect.x4 = f22;

                        if (shapID == 29)
                            shapRect.x1 = f3;

                        if (shapID == 30)
                            shapRect.x2 = f4;

                        if (shapID == 31)
                        {
                            shapRect.x1 = f3;
                            shapRect.x2 = f4;
                        }
                    }
                    #endregion 3方向隣接パターン (16通り)

                    #region 2方向隣接パターン (10通り)
                    if (shapID == 32)
                    {
                        shapRect.x1 = f17;
                        shapRect.x3 = f13;

                        shapRect.x2 = f20;
                        shapRect.x4 = f16;
                    }

                    if (shapID == 33)
                    {
                        shapRect.x1 = f11;
                        shapRect.x2 = f10;

                        shapRect.x3 = f23;
                        shapRect.x4 = f22;
                    }

                    if (shapID >= 34 && shapID <= 35)
                    {
                        // if (shapID == 34)
                        shapRect.x1 = f9;
                        shapRect.x2 = f10;
                        shapRect.x3 = f13;

                        if (shapID == 35)
                            shapRect.x4 = f8;
                    }

                    if (shapID >= 36 && shapID <= 37)
                    {
                        // if (shapID == 36)
                        shapRect.x1 = f11;
                        shapRect.x2 = f12;
                        shapRect.x4 = f16;

                        if (shapID == 37)
                            shapRect.x3 = f7;
                    }

                    if (shapID >= 38 && shapID <= 39)
                    {
                        // if (shapID == 38)
                        shapRect.x2 = f20;
                        shapRect.x3 = f23;
                        shapRect.x4 = f24;

                        if (shapID == 39)
                            shapRect.x1 = f3;
                    }

                    if (shapID >= 40 && shapID <= 41)
                    {
                        // if (shapID == 40)
                        shapRect.x1 = f17;
                        shapRect.x3 = f21;
                        shapRect.x4 = f22;

                        if (shapID == 41)
                            shapRect.x2 = f4;
                    }
                    #endregion 2方向隣接パターン (10通り)

                    if (shapID >= 42 && shapID <= 47)
                    {
                        #region 1方向隣接パターン (4通り)
                        //if (shapID == 46 || shapID == 47)
                        shapRect.x1 = f1;
                        shapRect.x2 = f2;
                        shapRect.x3 = f5;
                        shapRect.x4 = f6;

                        if (shapID >= 42)
                        {
                            shapRect.x3 = f13;
                            shapRect.x4 = f16;
                        }

                        if (shapID >= 43)
                        {
                            shapRect.x2 = f10;
                            shapRect.x4 = f22;
                        }
                        #endregion 1方向隣接パターン (4通り)

                        // 非隣接パターン (1通り)
                        if (shapID >= 44)
                        {
                            shapRect.x1 = f17;
                            shapRect.x2 = f20;
                        }

                        // 代表パターン (1通り)
                        if (shapID >= 45)
                        {
                            shapRect.x1 = f12;
                            shapRect.x3 = f24;
                        }

                    }

                    return shapRect;
                }
                #endregion 床

                #region 壁 shapID 0～15
                if (AutotileType == 2)
                {
                    ShapData shapRect = new ShapData
                    {
                        x1 = w6,
                        x2 = w7,
                        x3 = w10,
                        x4 = w11
                    };

                    // 4方向隣接パターン (1通り)
                    if (shapID == 0)
                        return shapRect;

                    #region 3方向隣接パターン(4通り)
                    if (shapID == 1)
                    {
                        shapRect.x1 = w5;
                        shapRect.x3 = w9;

                        shapRect.x2 = w6;
                        shapRect.x4 = w10;
                    }

                    if (shapID == 2)
                    {
                        shapRect.x1 = w2;
                        shapRect.x2 = w3;

                        shapRect.x3 = w6;
                        shapRect.x4 = w7;
                    }

                    if (shapID == 3)
                    {
                        shapRect.x1 = w1;
                        shapRect.x2 = w2;
                        shapRect.x3 = w5;
                        shapRect.x4 = w6;
                    }

                    if (shapID == 4)
                    {
                        shapRect.x1 = w7;
                        shapRect.x2 = w8;

                        shapRect.x3 = w11;
                        shapRect.x4 = w12;
                    }
                    #endregion 3方向隣接パターン(4通り)

                    #region 2方向隣接パターン (6通り)
                    if (shapID == 5)
                    {
                        shapRect.x1 = w5;
                        shapRect.x3 = w9;

                        shapRect.x2 = w8;
                        shapRect.x4 = w12;
                    }

                    if (shapID == 6)
                    {
                        shapRect.x1 = w3;
                        shapRect.x2 = w4;
                        shapRect.x3 = w7;
                        shapRect.x4 = w8;
                    }

                    if (shapID == 7)
                    {
                        shapRect.x1 = w1;
                        shapRect.x2 = w4;

                        shapRect.x3 = w5;
                        shapRect.x4 = w8;
                    }

                    if (shapID == 8)
                    {
                        shapRect.x1 = w10;
                        shapRect.x2 = w11;
                        shapRect.x3 = w14;
                        shapRect.x4 = w15;
                    }

                    if (shapID == 9)
                    {
                        shapRect.x1 = w9;
                        shapRect.x2 = w10;
                        shapRect.x3 = w13;
                        shapRect.x4 = w14;
                    }

                    if (shapID == 10)
                    {
                        shapRect.x1 = w2;
                        shapRect.x2 = w3;
                        shapRect.x3 = w14;
                        shapRect.x4 = w15;
                    }
                    #endregion 2方向隣接パターン (6通り)

                    #region 1方向隣接パターン (4通り)
                    if (shapID == 11)
                    {
                        shapRect.x1 = w1;
                        shapRect.x2 = w2;
                        shapRect.x3 = w13;
                        shapRect.x4 = w14;
                    }

                    if (shapID == 12)
                    {
                        shapRect.x1 = w11;
                        shapRect.x2 = w12;
                        shapRect.x3 = w15;
                        shapRect.x4 = w16;
                    }

                    if (shapID == 13)
                    {
                        shapRect.x1 = w9;
                        shapRect.x2 = w12;
                        shapRect.x3 = w13;
                        shapRect.x4 = w16;
                    }

                    if (shapID == 14)
                    {
                        shapRect.x1 = w3;
                        shapRect.x2 = w4;
                        shapRect.x3 = w15;
                        shapRect.x4 = w16;
                    }
                    #endregion 1方向隣接パターン (4通り)

                    // 非隣接パターン (1通り)
                    if (shapID == 15)
                    {
                        shapRect.x1 = w1;
                        shapRect.x2 = w4;
                        shapRect.x3 = w13;
                        shapRect.x4 = w16;
                    }

                    return shapRect;
                }
                #endregion 壁 shapID 0～15

                #region 滝 ShapID 0～4
                if (AutotileType == 3)
                {
                    // shapID
                    ShapData shapRect = new ShapData
                    {
                        x1 = t2,
                        x2 = t3,
                        x3 = t6,
                        x4 = t7
                    };

                    //両方向隣接パターン(1通り)
                    if (shapID == 0)
                        return shapRect;

                    // 片方向隣接パターン (2通り)
                    if (shapID == 1)
                    {
                        shapRect.x1 = t1;
                        shapRect.x2 = t2;
                        shapRect.x3 = t5;
                        shapRect.x4 = t6;
                    }

                    if (shapID == 2)
                    {
                        shapRect.x1 = t3;
                        shapRect.x2 = t4;
                        shapRect.x3 = t7;
                        shapRect.x4 = t8;
                    }


                    // 非隣接パターン (1通り)
                    if (shapID == 3)
                    {
                        shapRect.x1 = t1;
                        shapRect.x2 = t4;
                        shapRect.x3 = t5;
                        shapRect.x4 = t8;
                    }

                    return shapRect;
                }
                #endregion 滝 ShapID 0～4

                return new ShapData() { IsAutoShape = false, x1 = rect };
            }

            public ShapData[] GetPixelData()
            {
                if (IsAnimationTile)
                {
                    // floor
                    if (AutotileType == 1)
                    {
                        var floorW = rect.width / 3;
                        var floorH = rect.height;

                        ShapData floor1 = new ShapData() { IsAutoShape = true };
                        ShapData floor2 = new ShapData() { IsAutoShape = true };
                        floor2.x1.x += floorW;
                        floor2.x2.x += floorW;
                        floor2.x3.x += floorW;
                        floor2.x4.x += floorW;

                        ShapData floor3 = new ShapData() { IsAutoShape = true };
                        var ww = floorW * 2;
                        floor3.x1.x += ww;
                        floor3.x2.x += ww;
                        floor3.x3.x += ww;
                        floor3.x4.x += ww;

                        return new ShapData[] { floor1,floor2,floor3 };
                    }

                    // Waterfall
                    if (AutotileType == 3)
                    {
                        var fallW = rect.width;
                        var fallH = rect.height / 3;

                        ShapData fall1 = new ShapData() { IsAutoShape = true };
                        ShapData fall2 = new ShapData() { IsAutoShape = true };
                        fall2.x1.y += fallW;
                        fall2.x2.y += fallW;
                        fall2.x3.y += fallW;
                        fall2.x4.y += fallW;

                        ShapData fall3 = new ShapData() { IsAutoShape = true };
                        var ww = fallW * 2;
                        fall3.x1.y += ww;
                        fall3.x2.y += ww;
                        fall3.x3.y += ww;
                        fall3.x4.y += ww;

                        return new ShapData[] { fall1, fall2, fall3 };
                    }


                }

                return new ShapData[] { GetShapData() };
            }
        }
        #endregion TileData

        #region GetTile
        Dictionary<TileBase,Vector2> GetTile(TilesetsData[] tilesetsData, TileData tileData)
        {
            Dictionary < TileBase,Vector2> tiles = new Dictionary<TileBase, Vector2>();

            var halfW = TileSize.x / 2;
            var halfH = TileSize.y / 2;

            foreach (var tileset in tilesetsData)
            {
                var tilesetName = tileset.GetTilesetName(tileData.setnumber);

                List<Sprite> tileSprites = new List<Sprite>();
                List<Sprite> tileSprites2 = new List<Sprite>();
                List<Sprite> tileSprites3 = new List<Sprite>();
                List<Sprite> tileSprites4 = new List<Sprite>();

                foreach (var shapeData in tileData.GetPixelData())
                {
                    // オートタイルの取得
                    if (tileData.IsAnimationTile)
                    {
                        tileSprites.Add(tileset.GetSprite(shapeData.x1, tilesetName));
                        tileSprites2.Add(tileset.GetSprite(shapeData.x2, tilesetName));
                        tileSprites3.Add(tileset.GetSprite(shapeData.x3, tilesetName));
                        tileSprites4.Add(tileset.GetSprite(shapeData.x4, tilesetName));
                    }
                    else
                    {
                        if (shapeData.IsAutoShape)
                        {
                            tileSprites.Add(tileset.GetSprite(shapeData.x1, tilesetName));
                            tileSprites.Add(tileset.GetSprite(shapeData.x2, tilesetName));
                            tileSprites.Add(tileset.GetSprite(shapeData.x3, tilesetName));
                            tileSprites.Add(tileset.GetSprite(shapeData.x4, tilesetName));
                        }
                        else
                            tileSprites.Add(tileset.GetSprite(shapeData.x1, tilesetName));
                    }
                }

                if (tileData.IsAnimationTile)
                {
                    // オートタイルアニメーションの設定
                    AnimatedTile animTile = new AnimatedTile();
                    animTile.m_AnimatedSprites = tileSprites.ToArray();
                    AnimatedTile animTile2 = new AnimatedTile();
                    animTile2.m_AnimatedSprites = tileSprites2.ToArray();
                    AnimatedTile animTile3 = new AnimatedTile();
                    animTile3.m_AnimatedSprites = tileSprites3.ToArray();
                    AnimatedTile animTile4 = new AnimatedTile();
                    animTile4.m_AnimatedSprites = tileSprites4.ToArray();

                    tiles.Add(animTile, new Vector2());
                    tiles.Add(animTile2, new Vector2(halfW, 0));
                    tiles.Add(animTile3, new Vector2(0, halfH));
                    tiles.Add(animTile4, new Vector2(halfW, halfH));
                }
                else
                {
                    List<Tile> ttt = new List<Tile>();
                    foreach (var sp in tileSprites)
                    {
                        Tile chachTile = new Tile();
                        chachTile.sprite = sp;
                    }

                    // オートタイルのタイル設定
                    if (tileData.AutotileType == 0)
                    {
                        tiles.Add(ttt[0], new Vector2());
                        tiles.Add(ttt[1], new Vector2(halfW, 0));
                        tiles.Add(ttt[2], new Vector2(0, halfH));
                        tiles.Add(ttt[3], new Vector2(halfW, halfH));
                    }
                    else
                        tiles.Add(ttt[0], new Vector2());
                }
            }

            return tiles;
        }
        #endregion GetTile

        public void SetMapComponent(Tilemap tilemapComponent, string mapName)
        {
            // マップ名のマップを取得
            TkoolJsonData.Map targetMap = null;
            TkoolJsonData.MapInfoItem targetMapinfo = null;
            foreach (var info in mapinfoes)
            {
                if (info.Name == mapName)
                {
                    targetMap = maps[mapName];
                    targetMapinfo = info;
                }
            }

            // TODO:タイルデータから画像を読み込んでキャッシュ
            // タイルセットのテクスチャを作成
            var tilesetsData = GetTilesetsData(targetMap.TilesetId);

            List<TileData> TileDatas = new List<TileData>();
            for (int x = 0; x < targetMapinfo.ScrollX; x++)
            {
                for (int y = 0; y < targetMapinfo.ScrollY; y++)
                {
                    var tileID = targetMap.Data[x * y];
                    // 形状ID（オートタイルの生成位置）から、タイルデータ取得
                    var tileData = GetTileData(tileID);
                    TileDatas.Add(tileData);

                    // TODO:オートタイルは四分割されてて思いので一つのタイルにくっつけとかないと４倍遅くなる
                    var oneTile = GetTile(tilesetsData, tileData);

                    foreach (var oneone in oneTile)
                    {
                        // タイルを設定
                        tilemapComponent.SetTile(new Vector3Int(x + (int)oneone.Value.x, y + (int)oneone.Value.y, 0), oneone.Key);
                    }
                }
            }
        }
    }
}
