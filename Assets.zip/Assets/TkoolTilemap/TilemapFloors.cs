﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets
{
    public enum TilemapFloors
    {
        下層,
        下層重ね合わせ,
        上層1,
        上層2,
        /// <summary>
        /// 下位から左上/右上/左下/右下
        /// </summary>
        影ビットフラグ,
        リージョンID
    }
}
