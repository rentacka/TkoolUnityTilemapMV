﻿using Assets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TileMapRealChangerTest : MonoBehaviour {
    // ↑画像タイル取得に関係ない


    // Use this for initialization
    void Start () {
        var tilemapComponent = ComponentCreator.AddGridTilemapObj();


        // Mapjsonからタイルを読み込み
        TkoolTilemapManager tilemapReader = new TkoolTilemapManager("Test", @"E:\Mydocument\RPGMV\Test_Sample\");

        tilemapReader.SetMapComponent(tilemapComponent,"Map001");
    }

    // Update is called once per frame
    void Update () {

    }
}
