//  SlicedSpriteUtility.cs
//  http://kan-kikuchi.hatenablog.com/entry/SlicedSpriteUtility
//
//  Created by kan.kikuchi on 2016.09.06.

using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// SliceしたSpriteの取得を簡単にし、キャッシュもする便利クラス
/// </summary>
public static class SlicedSpriteUtility {

  //ロードしたスプライトのキャッシュ<画像のパス,<SliceしたSprite名, Sprite>>
  private static Dictionary<string, Dictionary<string, Sprite>> _permamentCacheDict = new Dictionary<string, Dictionary<string, Sprite>>();
  private static Dictionary<string, Dictionary<string, Sprite>> _temporaryCacheDict = new Dictionary<string, Dictionary<string, Sprite>>();

  //永久にキャッシュする画像のパス
  private readonly static List<string> PERMAMENT_SPRITE_PATH_LIST = new List<string>(){
    
  };

  //=================================================================================
  //スプライトをロード
  //=================================================================================

  /// <summary>
  /// 指定したパスにあるSliceした全スプライトをロード
  /// </summary>
  public static Dictionary<string, Sprite> LoadSpriteDict(string filePath){

    //パスによってキャッシュを変更
    Dictionary<string, Dictionary<string, Sprite>> cacheDict = PERMAMENT_SPRITE_PATH_LIST.Contains(filePath) ? _permamentCacheDict : _temporaryCacheDict;

    //取得したことのないパスなら画像を取得
    if(!cacheDict.ContainsKey(filePath)){
      //Sliceしたスプライトを全て取得
      Sprite[] spriteArray = Resources.LoadAll<Sprite>(filePath);
      if(spriteArray.Length == 0){
        Debug.LogWarning(filePath + "がありません！");
      }

      //SliceしたSpriteを名前をKeyにして登録
      Dictionary<string, Sprite> spriteDict = new Dictionary<string, Sprite>();

      for (int i = 0; i < spriteArray.Length; i++) {
        spriteDict[spriteArray[i].name] = spriteArray[i];
      }

      //キャッシュ
      cacheDict[filePath] = spriteDict;
    }

    //キャッシュを返す
    return cacheDict[filePath];
  }

  /// <summary>
  /// ファイル名とスプライト名を指定してスプライトをロードする
  /// </summary>
  public static Sprite LoadSprite(string filePath, string spriteName){
    if(string.IsNullOrEmpty(filePath)){
      Debug.LogWarning("パスが空です！ : " + spriteName);
    }

    Dictionary<string, Sprite> spriteDict = LoadSpriteDict(filePath);

    if(!spriteDict.ContainsKey(spriteName)){
      Debug.LogWarning(filePath + "に" + spriteName + "はありません！");
      return null;
    }

    return spriteDict[spriteName];
  }

  //=================================================================================
  //破棄
  //=================================================================================

  /// <summary>
  /// キャッシュしているスプライトを破棄する
  /// </summary>
  public static void ClearCache(){
    _temporaryCacheDict.Clear();
  }

}