﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections;

namespace Assets
{
    class ComponentCreator
    {
        public static Tilemap AddGridTilemapObj()
        {
            GameObject parentGrid = new GameObject();
            GameObject.Instantiate(parentGrid);
            parentGrid.AddComponent<Grid>();

            GameObject tilemapObj = new GameObject();
            Object.Instantiate(tilemapObj);
            // tilemapの親にGridを設定
            tilemapObj.transform.parent = parentGrid.transform;
            tilemapObj.AddComponent<Tilemap>();
            tilemapObj.AddComponent<TilemapRenderer>();

            var tilemapComponent = tilemapObj.GetComponent<Tilemap>();
            return tilemapComponent;
        }
    }
}
