﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets
{
    class SwitchNode:IStateNode
    {
        public string Selection;

        List<SwitchNode> Pins = new List<SwitchNode>();

        public override void Execute()
        {
            int pinCount = 0;
            foreach (var pin in Pins)
            {
                if (Selection == pin.Selection && pin.NextState != null)
                {
                    IStateNode.NextMethod(pin);

                    Log("スイッチ分岐" +"(" +Selection+")：実行"+ pinCount.ToString());

                    break;
                }

                pinCount++;
            }

            //base.Execute();
        }
    }
}
