﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;

namespace Assets
{
    public class JsonSon
    {
        /// <summary>
        /// Jsonをデータパスから読み込み
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="isDataPath">true:データファイル名 false:リソースファイル名</param>
        /// <returns></returns>
        public static object Read(string fileName,bool isDataPath = true)
        {
            return Setup(fileName, null, isDataPath);
        }

        /// <summary>
        /// JsonをWindowsパスから読み込み
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="projPath"></param>
        /// <returns></returns>
        public static object Read(string fileName, string projPath)
        {
            return Setup(fileName, projPath, false);
        }

        static object Setup(string assetPath,string projPath = null,bool isDataPath = true)
        {
            string textData;

            if (projPath!=null || isDataPath)
            {
                string dataPath = null;

                if (isDataPath)
                {
                    // Application.dataPathで/Assets/filePathになる
                    dataPath = Application.dataPath + assetPath;
                }
                else
                    dataPath = Path.Combine(projPath, assetPath);

                // 読み込む
                System.IO.StreamReader reader = new System.IO.StreamReader(
                    dataPath,
                    // エンコーディング
                    System.Text.Encoding.GetEncoding("utf-8"));
                // 内容をすべて読み込む
                textData = reader.ReadToEnd();
                // 閉じる
                reader.Close();
            }
            else
            {
                TextAsset txt = UnityEngine.Object.Instantiate(Resources.Load(assetPath)) as TextAsset;
                textData = txt.text;
            }

            // 空白を置換で削除
            textData = System.Text.RegularExpressions.Regex.Replace(textData, @" ", "");

            var obj = JsonConvert.DeserializeObject(textData);

            return obj;
        }

        public static void Write(object item, string _targetPath)
        {
            var json = JsonConvert.SerializeObject(item);

            StreamWriter sw = new StreamWriter(_targetPath, false);// TextData.txtというファイルを新規で用意
            sw.WriteLine(json);// ファイルに書き出したあと改行
            sw.Flush();// StreamWriterのバッファに書き出し残しがないか確認
            sw.Close();// ファイルを閉じる
        }
    }
}
