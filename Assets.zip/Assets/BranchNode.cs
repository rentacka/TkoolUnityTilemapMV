﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets
{
    class BranchNode : IStateNode
    {
        public bool Condition = false;

        public IStateNode TRUE;
        public IStateNode FALSE;

        public override void Execute()
        {
            if (Condition)
            {
                IStateNode.NextMethod(TRUE);
            }
            else
            {
                IStateNode.NextMethod(FALSE);
            }

            Log("条件分岐:" + Condition.ToString());
        }
    }
}
