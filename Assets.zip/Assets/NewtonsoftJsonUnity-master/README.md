Json.NET trimmed down to compile in Unity 5.

http://www.newtonsoft.com/json/help/html/Introduction.htm